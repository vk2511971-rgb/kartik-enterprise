Kartik Enterprises website
1. Open index.html in a browser to preview.
2. Replace YOUR_EMAIL@example.com with your real email.
3. Replace/add your WhatsApp number and other contact details before publishing.
4. Upload index.html to your hosting.
5. Connect your domain (for example, kartikenterprises.com) through your domain/hosting provider.
